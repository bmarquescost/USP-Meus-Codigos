#ifndef _PKDEX_H
#define _PKDEX_H

#include "Pokemon.h"

pokemon_t** readPkDex(int *nEntries, char *fileName);

#endif //_PKDEX_H
