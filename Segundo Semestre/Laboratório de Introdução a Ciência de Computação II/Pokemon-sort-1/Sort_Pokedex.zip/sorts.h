#ifndef _SORTS_H_
#define _SORTS_H_

#include "Pokemon.h"
#include "PokeDex.h"
#include "PokeType.h"

void pokelist_sort(pokemon_t **pokelist, int num_pokemons, int sort_algoritm, char *field_compared);


#endif